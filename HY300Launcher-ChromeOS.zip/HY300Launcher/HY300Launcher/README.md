# HY300 Launcher — starter project

Primeira base funcional de launcher Android nativo, com interface escura inspirada na Apple TV e navegação por controle remoto.

## Antes de compilar: identificar o projetor

Com a depuração USB ativada e o HY300 conectado ao computador, abra um terminal e execute:

```bash
adb devices
adb shell getprop ro.build.version.release
adb shell getprop ro.build.version.sdk
adb shell getprop ro.product.cpu.abi
adb shell wm size
adb shell wm density
```

Envie os resultados antes de instalar o APK. Eles determinam a versão real do Android, arquitetura e resolução reportada pelo aparelho.

## Abrir e compilar

Abra esta pasta no Android Studio ou no Antigravity com o Android SDK instalado. Use JDK 17 ou superior e sincronize o projeto Gradle. Compile com:

```bash
gradle assembleDebug
```

O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar para testar

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Depois pressione Home no controle remoto e escolha **HY300 Launcher**. Inicialmente, selecione apenas uma vez ou use a opção temporária, se o Android oferecer essa escolha. Não desative nem remova o launcher original.

## Estado desta versão

- Launcher Android com intent HOME/DEFAULT.
- Lista os aplicativos que declaram atividade de inicialização.
- Abre aplicativos pelo OK/clique.
- Foco visual para navegação por controle remoto.
- Interface escura e leve, sem dependências externas de UI.

Ainda é uma base inicial: favoritos editáveis, atualização de relógio em tempo real, atalhos de sistema e refinamento visual serão implementados após validar Android/firmware e comportamento do controle no aparelho.
