package com.hy300.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 10, 13)
    private val panel = Color.rgb(25, 27, 33)
    private val muted = Color.rgb(157, 160, 170)
    private val white = Color.rgb(244, 244, 247)
    private lateinit var root: LinearLayout
    private lateinit var appGrid: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LOW_PROFILE
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        if (::appGrid.isInitialized) populateApps()
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(26), dp(42), dp(22))
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "HY300"
            textSize = 15f
            letterSpacing = 0.18f
            setTextColor(muted)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val spacer = View(this)
        val clock = TextView(this).apply {
            textSize = 14f
            setTextColor(muted)
            text = SimpleDateFormat("EEE, d MMM  •  HH:mm", Locale.getDefault()).format(Date())
        }
        header.addView(brand)
        header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(clock)
        root.addView(header, LinearLayout.LayoutParams(-1, dp(34)))

        val greeting = TextView(this).apply {
            text = "O que vamos assistir?"
            textSize = 29f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val greetParams = LinearLayout.LayoutParams(-1, -2)
        greetParams.topMargin = dp(30)
        root.addView(greeting, greetParams)

        val sub = TextView(this).apply {
            text = "Seus aplicativos"
            textSize = 14f
            setTextColor(muted)
        }
        val subParams = LinearLayout.LayoutParams(-1, -2)
        subParams.topMargin = dp(9)
        root.addView(sub, subParams)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        appGrid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(20), 0, dp(12))
        }
        scroll.addView(appGrid)
        val scrollParams = LinearLayout.LayoutParams(-1, 0, 1f)
        root.addView(scroll, scrollParams)

        val footer = TextView(this).apply {
            text = "HY300 Launcher  •  Versão inicial"
            textSize = 11f
            setTextColor(Color.rgb(93, 96, 106))
            gravity = Gravity.END
        }
        root.addView(footer, LinearLayout.LayoutParams(-1, dp(22)))
        setContentView(root)
        populateApps()
    }

    private fun populateApps() {
        appGrid.removeAllViews()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<ResolveInfo> = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }

        if (apps.isEmpty()) {
            appGrid.addView(TextView(this).apply {
                text = "Nenhum aplicativo encontrado."
                setTextColor(muted)
                textSize = 16f
            })
            return
        }

        val columns = 5
        apps.chunked(columns).forEach { group ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }
            group.forEach { info -> row.addView(createAppTile(info), LinearLayout.LayoutParams(0, dp(116), 1f)) }
            repeat(columns - group.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            val params = LinearLayout.LayoutParams(-1, dp(126))
            appGrid.addView(row, params)
        }
    }

    private fun createAppTile(info: ResolveInfo): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            background = rounded(panel, dp(16))
            setPadding(dp(8), dp(9), dp(8), dp(8))
            contentDescription = info.loadLabel(packageManager).toString()
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launch != null) try { startActivity(launch) } catch (_: Exception) { }
            }
            setOnFocusChangeListener { view, focused ->
                view.background = rounded(if (focused) Color.rgb(62, 65, 76) else panel, dp(16))
                view.scaleX = if (focused) 1.035f else 1f
                view.scaleY = if (focused) 1.035f else 1f
            }
        }
        val icon = TextView(this).apply {
            text = ""
            gravity = Gravity.CENTER
            setCompoundDrawablesWithIntrinsicBounds(null, info.loadIcon(packageManager), null, null)
        }
        tile.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        val label = TextView(this).apply {
            text = info.loadLabel(packageManager).toString()
            textSize = 12f
            setTextColor(white)
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val labelParams = LinearLayout.LayoutParams(-1, dp(38))
        labelParams.topMargin = dp(8)
        tile.addView(label, labelParams)
        return tile
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
