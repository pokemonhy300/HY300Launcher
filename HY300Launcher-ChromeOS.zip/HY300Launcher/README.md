# HY300 Launcher — starter project

Base inicial de um launcher Android nativo, com interface escura inspirada na Apple TV e navegação por controle remoto. O projeto está preparado para gerar um APK de teste pelo GitHub Actions, sem precisar instalar Android Studio no Chromebook.

## Gerar o APK usando apenas o navegador do Chromebook

1. Entre em https://github.com e crie uma conta, caso ainda não tenha.
2. Crie um repositório novo chamado `HY300Launcher`. Deixe-o como **Private** ou **Public**.
3. Envie o conteúdo desta pasta para o repositório, mantendo a estrutura de pastas (inclusive `.github/workflows/build-apk.yml`).
4. Abra a aba **Actions** do repositório.
5. Se o GitHub pedir, confirme que deseja habilitar workflows.
6. Abra **Build HY300 Launcher APK** e clique em **Run workflow** (ou aguarde o primeiro push terminar).
7. Quando a execução ficar verde, abra a execução concluída e baixe o artefato `HY300Launcher-debug` na seção **Artifacts**.
8. Extraia o ZIP do artefato para obter `app-debug.apk`.

O GitHub Actions compila o projeto na nuvem. Não é necessário instalar Android Studio ou SDK no Chromebook.

## ADB por Wi-Fi a partir do Chromebook

**Importante:** ADB não funciona diretamente em uma aba do Chrome. Para usar ADB no Chromebook, normalmente é necessário ativar o ambiente Linux (Crostini) em Configurações > Avançado > Desenvolvedores > Ambiente de desenvolvimento Linux e instalar as ferramentas dentro dele. Se você não quiser ativar Linux, ainda pode compilar o APK pelo GitHub Actions e transferi-lo ao projetor por outro método compatível.

Depois de ativar Linux, abra o Terminal Linux e instale as ferramentas:

```bash
sudo apt update
sudo apt install adb
```

No HY300, habilite as opções de desenvolvedor e a depuração sem fio. Em **Depuração sem fio**, use **Parear dispositivo com código**. No Terminal Linux, execute os comandos mostrados pelo próprio projetor, normalmente neste formato:

```bash
adb pair IP_DO_PROJETOR:PORTA_DE_PAREAMENTO
```

Digite o código exibido no projetor. Em seguida, conecte usando o endereço e a porta mostrados na tela de Depuração sem fio:

```bash
adb connect IP_DO_PROJETOR:PORTA_DE_CONEXAO
adb devices
```

O endereço e as portas são dinâmicos: use os valores exibidos no HY300, não os exemplos acima.

Se o firmware não oferecer **Depuração sem fio**, pode ser necessário ativar ADB TCP por USB inicialmente; isso depende das opções disponíveis no firmware. Não presuma que a porta 5555 esteja aberta.

## Identificar o Android e o hardware

Com o ADB conectado, execute:

```bash
adb shell getprop ro.build.version.release
adb shell getprop ro.build.version.sdk
adb shell getprop ro.product.cpu.abi
adb shell wm size
adb shell wm density
```

Envie os resultados para ajustar o projeto ao firmware, arquitetura e resolução reais.

## Instalar para teste

Com o APK no Chromebook e o ADB conectado:

```bash
adb install -r app-debug.apk
```

Depois pressione Home no controle remoto e escolha **HY300 Launcher**. Teste primeiro sem desativar nem remover o launcher original. Só defina o novo launcher como padrão depois de confirmar que ele abre aplicativos e responde corretamente ao controle.

## Estado desta versão

- Activity declarada como launcher HOME/DEFAULT.
- Lista aplicativos que declaram atividade de inicialização.
- Abre aplicativos pelo OK/clique.
- Foco visual para navegação por controle remoto.
- Interface escura e leve, sem dependências externas de UI.
- Workflow do GitHub Actions para compilar e disponibilizar o APK.

Ainda é uma base inicial. Favoritos editáveis, relógio atualizado em tempo real, atalhos de sistema e refinamento visual serão implementados depois de validar o firmware e o controle remoto no aparelho.
